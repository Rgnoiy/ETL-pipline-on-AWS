import pandas as pd
import psycopg2
from sqlalchemy import create_engine

df = pd.read_csv('example_transactions.csv')

df.drop(columns=['card_number'], inplace=True)
df.drop(columns=['customer_name'], inplace=True)

df["items"] = df["basket_items"].apply(lambda x: x.split(","))
df1 = df.explode("items")
items = df1['items']
store = df['store'].drop_duplicates().to_frame()                # TODO
# Rename column names to match DB columns
store.rename(columns={'store':'store_name'}, inplace=True)


transaction = df.drop(columns=['basket_items', 'items'])
transaction['store'] = transaction['store'].apply(lambda x: pd.Index(store['store_name']).get_loc(x)+1)  # TODO
# Rename column names to match DB columns
transaction.rename(columns={'store':'store_id', 'cash_or_card':'payment_method'}, inplace=True)


# separate product&flavor and price
result = items.str.rsplit(pat='-', n=1, expand=True)
result[0] = result[0].apply(lambda x: x.strip(' '))


# product list with price
products = result.reset_index(drop=True)
products[0] = products[0].apply(lambda x: x.strip(' '))
product_list = products.drop_duplicates(subset=[0], keep='first', ignore_index=True)    # TODO
# Rename column names to match DB columns
product_list.rename(columns={0: 'product_name', 1: 'price'}, inplace=True)


# transac id + product_name + quantity
basket_items = result[0].to_frame()
basket_items = basket_items.groupby(basket_items.index)[0].apply(lambda x: x.value_counts()).to_frame()
basket_items = basket_items.reset_index()


# transac id + product_id + quantity
basket_items['level_1'] = basket_items['level_1'].apply(lambda x: pd.Index(product_list['product_name']).get_loc(x)+1)
basket_items['level_0'] = basket_items['level_0'] + 1
basket_items_with_quantity = basket_items   # TODO
# Rename column names to match DB columns
basket_items_with_quantity.rename(columns={'level_0':'transaction_id', 'level_1':'product_id', 0:'quantity'}, inplace=True)

# Start connection to DB
conn = psycopg2.connect(host="localhost", user="root", password="password", dbname="postgres")
cur = conn.cursor()

engine = create_engine('postgresql://root:password@localhost:5432/postgres')

# Load store table
store.to_sql('store', con=engine, index=False, if_exists='replace')

# Load transaction Table
transaction.to_sql('transaction', con=engine, index=False, if_exists='replace')

# Load product table
product_list.to_sql('product', con=engine, index=False, if_exists='replace')

# Load basket table
basket_items_with_quantity.to_sql('basket', con=engine, index=False, if_exists='replace')

cur.close()
conn.close()



