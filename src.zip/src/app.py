import pandas as pd
import psycopg2
import os
from time import sleep
from dotenv import load_dotenv

print("App has started")
# we want to give our database time to startup completely
# so we are sleeping the app for 10 seconds then try to connect to db
sleep(10)

# establishing connection to database
conn = psycopg2.connect(host="localhost", user="root", password="password", dbname="postgres")
cur = conn.cursor()

print("Database connect successful")

# cursor = connection.cursor()

# creating mysql tables
create_transaction = """
CREATE TABLE IF NOT EXISTS transaction(
  transaction_id SERIAL PRIMARY KEY,
  timestamp varchar(250),
  store_id int,
  total_price FLOAT,
  payment_method varchar(250)
  );
"""

create_basket = """
CREATE TABLE IF NOT EXISTS basket(
  transaction_id int,
  product_id int,
  quantity int
  );
"""

create_product = """
CREATE TABLE IF NOT EXISTS PRODUCT(
  product_id SERIAL PRIMARY KEY ,
  product_name varchar(250),
  price FLOAT
  );
"""

create_store = """
CREATE TABLE IF NOT EXISTS STORE(
  store_id SERIAL PRIMARY KEY,
  store_name varchar(250)
  );
"""

cur.execute(create_transaction)
cur.execute(create_basket)
cur.execute(create_product)
cur.execute(create_store)
conn.commit()


# close connection
cur.close()
conn.close()

