import pymysql
import os
from dotenv import load_dotenv

class Team4Database:
    def __init__(self):
        print("Starting database connection")

        load_dotenv()
        host = os.environ.get("mysql_host")
        user = os.environ.get("mysql_user")
        password = os.environ.get("mysql_pass")
        database = os.environ.get("mysql_db")
        port = int(os.environ.get("mysql_port"))

       # Establish a database connection
        self.connection = pymysql.connect(
            host=host,
            user=user,
            password=password,
            port=port,
            database=database,
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor)

        print("Database connect successful")
